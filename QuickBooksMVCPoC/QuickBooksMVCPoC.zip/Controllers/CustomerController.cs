﻿using Intuit.Ipp.Core;
using Intuit.Ipp.Data;
using Intuit.Ipp.DataService;
using Intuit.Ipp.Security;
using QuickBooksMVCPoC.Models;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Mvc;

namespace QuickBooksMVCPoC.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        public ActionResult Index()
        {
            string accessToken = Session["AccessToken"] as string;
            if (string.IsNullOrEmpty(accessToken))
            {
                return RedirectToAction("Authorize", "OAuth");
            }

            var oauthValidator = new OAuth2RequestValidator(accessToken);
            var settings = new QuickBooksSettings
            {
                ClientId = ConfigurationManager.AppSettings["ClientId"],
                Environment = ConfigurationManager.AppSettings["Environment"]
            };
            var serviceContext = new ServiceContext(null, IntuitServicesType.QBO, oauthValidator);
            var dataService = new DataService(serviceContext);
            List<Customer> customers = dataService.FindAll(new Customer(), 1, 100).ToList();

            return View(customers);
        }
    }
}