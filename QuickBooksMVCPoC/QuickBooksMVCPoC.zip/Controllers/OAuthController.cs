﻿using Intuit.Ipp.OAuth2PlatformClient;
using QuickBooksMVCPoC.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace QuickBooksMVCPoC.Controllers
{
    public class OAuthController : Controller
    {
        private readonly OAuth2Client _oauthClient;
        private readonly QuickBooksSettings _settings;

        public OAuthController()
        {
            _settings = new QuickBooksSettings
            {
                ClientId = ConfigurationManager.AppSettings["ClientId"],
                ClientSecret = ConfigurationManager.AppSettings["ClientSecret"],
                RedirectUri = ConfigurationManager.AppSettings["RedirectUri"],
                Environment = ConfigurationManager.AppSettings["Environment"]
            };

            if (string.IsNullOrEmpty(_settings.RedirectUri))
            {
                throw new ArgumentNullException("RedirectUri cannot be null or empty. Please ensure it is correctly configured in Web.config.");
            }

            _oauthClient = new OAuth2Client(
                _settings.ClientId,
                _settings.ClientSecret,
                _settings.RedirectUri,
                _settings.Environment
          
            );
           // _oauthClient.EnableAdvancedLoggerInfoMode = false;
           // _oauthClient.EnableSerilogRequestResponseLoggingForConsole = false;
           // _oauthClient.EnableSerilogRequestResponseLoggingForFile = false;
           // _oauthClient.EnableSerilogRequestResponseLoggingForDebug = false;
           // _oauthClient.EnableSerilogRequestResponseLoggingForTrace = false;

        }

        // Step 4.1: Initiate Authorization
        public ActionResult Authorize()
        {
            var scopes = new List<OidcScopes> { OidcScopes.Accounting };
            string authorizeUrl = _oauthClient.GetAuthorizationURL(scopes);
            return Redirect(authorizeUrl);
        }

        // Step 4.2: Handle the Callback
        public async Task<ActionResult> Callback(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return Content("Invalid callback parameters.");
            }

            try
            {
                // Exchange authorization code for access and refresh tokens
                var tokenResponse = await _oauthClient.GetBearerTokenAsync(code);
                Session["AccessToken"] = tokenResponse.AccessToken;
                Session["RefreshToken"] = tokenResponse.RefreshToken;
                return RedirectToAction("Connected");
            }
            catch (Exception ex)
            {
                return Content("An error occurred during the callback: " + ex.Message);
            }
        }

        // Display Connection Success
        public ActionResult Connected()
        {
            ViewBag.Message = "Successfully connected to QuickBooks.";
            return View();
        }
    }
}